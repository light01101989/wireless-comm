%% ECE 5680 - Wireless Communication
%% HW2: Ques 4_2
%% Author: Arjun Jauhari
%% Email/Netid: aj526
%% Date: 09/24/2015
%% Monte-Carlo simulation for estimating SER(Symbol Error rate) of QPSK in Fading channel

%clear all;close all;
function SER = HW2_Q4_2()
SNR_db = -10:20;  % Sweeping over SNR of -10dB to 20dB
SNR = 10.^(SNR_db/10);
sd = sqrt(2./SNR);  % Standard Deviation
var = sd.^2;        % Variance

%% STEP 1 OF MONTE CARLO SIMULATION
%% Generating transmit data
S_qpsk = [1+1i 1-1i -1+1i -1-1i];    %%QPSK
in_bits = randi([1 4], 1, 10000);
x_qpsk(1,length(in_bits)) = 0;
for k = 1:length(in_bits)
    x_qpsk(1,k) = S_qpsk(in_bits(k));
end


noise(length(sd),length(in_bits)) = 0;
x_hat(length(sd),length(in_bits)) = 0;
I_mc(length(sd),length(in_bits)) = 0;
SER(1,length(sd)) = 0;
y(length(sd),length(in_bits)) = 0;
y_new(length(sd),length(in_bits)) = 0;
h_channel(length(sd),length(in_bits)) = 0;

for k = 1:length(sd)
  %%STEP 2 OF M-C SIMULATION
  % Generating COMPLEX RANDOM NOISE WITH MEAN 0 AND VARIANCE VAR = N0
  noise(k,:) = (1/sqrt(2))*sd(1,k)*randn(1,10000) + 1i*(1/sqrt(2))*sd(1,k)*randn(1,10000);
  % Generating COMPLEX RANDOM CHANNEL MODEL WITH MEAN 0 AND VARIANCE VAR = 1
  h_channel(k,:) = (1/sqrt(2))*randn(1,10000) + 1i*(1/sqrt(2))*randn(1,10000);

  %%STEP 3 OF M-C SIMULATION
  %% RECEIVED SIGNAL ACCORDING TO RELATION y = hx + n
  y(k,:) = h_channel(k,:).*x_qpsk + noise(k,:);

  %% STEP 4 OF M-C SIMULATION
  %% Using the detector threshold to do detection and get x_hat
  %% On receiver we do (h/|h|) dot with y
  decision_bound = 0;
    for r = 1:length(y)
        y_new(k,r) = dot((h_channel(k,r)./norm(h_channel(k,r))),y(k,r));
    end
    
    for r = 1:length(y_new)
      if real(y_new(k,r)) < decision_bound
          if imag(y_new(k,r)) < decision_bound
              x_hat(k,r) = -1-1i;
          else
              x_hat(k,r) = -1+1i;
          end
      else
          if imag(y_new(k,r)) < decision_bound
              x_hat(k,r) = 1-1i;
          else
              x_hat(k,r) = 1+1i;
          end
      end
    end
        
  %% STEP 5 OF M-C SIMULATION
  %% Evaluate I
  for r = 1:length(x_hat)
    if x_hat(k,r) == x_qpsk(1,r)
      I_mc(k,r) = 0; %no error
    else
      I_mc(k,r) = 1; %error occured
    end
  end

  %%CALCULATE SER
  SER(1,k) = mean(I_mc(k,:));
  
end

%figure(1)
%plot(abs(y(1,:)))
%plot(real(y(30,:)),imag(y(30,:)),'o')
%%PLOTTING
figure(1)
semilogy(SNR_db,SER,'bo-')
grid on
axis([-10 20 1e-6 1])
xlabel('signal-to-noise ratio (SNR) [dB]')
ylabel('symbol error rate (SER)')
legend('QPSK FADING SER')
