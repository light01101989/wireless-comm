%% ECE 5680 - Wireless Communication
%% HW2: Ques 3
%% Author: Arjun Jauhari
%% Email/Netid: aj526
%% Date: 09/24/2015
%% Monte-Carlo simulation for estimating SER(Symbol Error rate)

%clear all;close all;
function [SER_qpsk ,SER_bpsk] = HW2_Q3()
SNR_db = -10:20;  % Sweeping over SNR of -10dB to 20dB
SNR = 10.^(SNR_db/10);
sd = sqrt(2./SNR);  % AJ:check % Standard Deviation
var = sd.^2;        % Variance

%% STEP 1 OF MONTE CARLO SIMULATION
%% Generating transmit data
S_qpsk = [1+1i 1-1i -1+1i -1-1i];    %%QPSK
S_bpsk = [-1 -1 1 1];    %%BPSK
in_bits = randi([1 4], 1, 10000);
x_qpsk(1,length(in_bits)) = 0;
x_bpsk(1,length(in_bits)) = 0;
for k = 1:length(in_bits)
    x_qpsk(1,k) = S_qpsk(in_bits(k));
    x_bpsk(1,k) = S_bpsk(in_bits(k));
end

noise(length(sd),length(in_bits)) = 0;
x_hat(length(sd),length(in_bits)) = 0;
I_mc(length(sd),length(in_bits)) = 0;
SER(1,length(sd)) = 0;
y(length(sd),length(in_bits)) = 0;
for m=1:2
for k = 1:length(sd)
  %%STEP 2 OF M-C SIMULATION
  % Generating RANDOM NOISE WITH MEAN 0 AND VARIANCE VAR == sd^2
  %noise(k,:) = sqrt(2)*sd(1,k)*randn(1,10000) + i*sqrt(2)*sd(1,k)*randn(1,10000);
  noise(k,:) = (1/sqrt(2))*sd(1,k)*randn(1,10000) + 1i*(1/sqrt(2))*sd(1,k)*randn(1,10000);
  %noise(k,:) = sd(1,k)*randn(1,10000) + i*sd(1,k)*randn(1,10000);

  %%STEP 3 OF M-C SIMULATION
  %% RECEIVED SIGNAL ACCORDING TO RELATION y = x + n
  if m==1
      y(k,:) = x_qpsk + noise(k,:);
  else
      y(k,:) = x_bpsk + noise(k,:);
  end

  %% STEP 4 OF M-C SIMULATION
  %% Using the detector threshold to do detection and get x_hat
  decision_bound = 0;
  if m == 1
    for r = 1:length(y)
      if real(y(k,r)) < decision_bound
          if imag(y(k,r)) < decision_bound
              x_hat(k,r) = -1-1i;
          else
              x_hat(k,r) = -1+1i;
          end
      else
          if imag(y(k,r)) < decision_bound
              x_hat(k,r) = 1-1i;
          else
              x_hat(k,r) = 1+1i;
          end
      end
    end
  else
      for r = 1:length(y)
          if real(y(k,r)) < decision_bound
              x_hat(k,r) = -1;
          else
              x_hat(k,r) = 1;
          end
      end
  end

  %% STEP 5 OF M-C SIMULATION
  %% Evaluate I
  if m == 1
      x_sent = x_qpsk;
  else
      x_sent = x_bpsk;
  end
  for r = 1:length(x_hat)
    if x_hat(k,r) == x_sent(1,r)
      I_mc(k,r) = 0; %no error
    else
      I_mc(k,r) = 1; %error occured
    end
  end

  %%CALCULATE SER
  SER(1,k) = mean(I_mc(k,:));
  
  %% Assign 
  if m == 1
      SER_qpsk = SER;
  else
      SER_bpsk = SER;
  end
end
end

%figure(1)
%plot(abs(y(1,:)))
%plot(real(y(30,:)),imag(y(30,:)),'o')
%%PLOTTING
figure(1)
semilogy(SNR_db,SER_qpsk,'bo-',SNR_db,SER_bpsk,'ko-')
grid on
axis([-10 20 1e-6 1])
xlabel('signal-to-noise ratio (SNR) [dB]')
ylabel('symbol error rate (SER)')
%legend('QPSK SER', 'BPSK SER')

hold on

%%calculation SER from analytical equation
%SER_calc = 0.5*erfc(sqrt(SNR./2));
%SER_calc = erfc(sqrt(SNR./2));
SER_calc = 2*qfunc(sqrt(SNR)) - qfunc(sqrt(SNR)).^2;
semilogy(SNR_db,SER_calc,'ro-')
legend('QPSK SER', 'BPSK SER', 'calculated SER')
